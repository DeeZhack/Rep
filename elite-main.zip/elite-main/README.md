# ♛✭ 𝙋𝙍𝙀𝙈𝙄𝙐𝙈 𝘾𝙍𝘼𝘾𝙆 ✭♛
<a href="https://github.com/Dapunta/elite"><img src="https://github-link-card.s3.ap-northeast-1.amazonaws.com/Dapunta/elite.png" width="460px"></a>
## ✯⇨𝙁𝙚𝙖𝙩𝙪𝙧𝙚𝙨⇦✯
[✯] Crack 4 Methode  
[✯] Login Token  
[✯] Login Cookies  
[✯] Token/Cookie Awet  
[✯] Fast Dump  
[✯] Fast Crack  
[✯] More Listpass  
## ✯⇨𝙄𝙣𝙨𝙩𝙖𝙡𝙡 𝙎𝙘𝙧𝙞𝙥𝙩 𝙊𝙣 𝙏𝙚𝙧𝙢𝙪𝙭⇦✯
$ pkg update && upgrade  
$ pkg install python2  
$ pkg install git  
$ pip2 install bs4  
$ pip2 install requests  
$ pip2 install mechanize  
$ git clone https://github.com/Dapunta/elite
## ✯⇨𝙍𝙪𝙣 𝙎𝙘𝙧𝙞𝙥𝙩⇦✯
$ cd elite  
$ python2 elite
## ✯⇨𝙃𝙤𝙬 𝙏𝙤 𝙐𝙨𝙚⇦✯
1. Cari Akun Target
2. Dump ID Terlebih Dahulu
3. Masukkan ID Target
4. Tunggu Hingga Selesai Dump
5. Setelah Selesai Dump, Maka Keluar Output File
6. Salin Output File
7. Tekan Kembali, Kemudian Mulai Crack
8. Masukkan File Output Tadi
## ✯⇨𝙎𝙘𝙧𝙚𝙚𝙣𝙨𝙝𝙤𝙩⇦✯
